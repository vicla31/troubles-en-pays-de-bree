
[utopiafonts] 1998 free font
----------------------------------------------------

this font is provided free for personal or commercial use,
it can be redistributed however it may not be sold.  

FREE FONTS
----------
if you would like your own free font, just send your handwriting
samples, concepts or scans to me at: dale_thorpe@bssc.edu.au

MAILING LIST
------------
join the utopiafonts mailing list by sending an email to:
subscribe-utopiafonts@egroups.com or just visit our webpage at:

http://utopiafonts.cjb.net/

----------------------------------------------------
� 1998 utopiafonts.